//
//  iPadScannerAppApp.swift
//  iPadScannerApp
//
//  Created by Marc Schneider-Handrup on 26.05.25.
//

import SwiftUI

@main
struct iPadScannerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
