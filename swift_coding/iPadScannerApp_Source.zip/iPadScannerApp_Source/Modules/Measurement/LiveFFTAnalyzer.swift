
import Foundation
import Accelerate
import AVFoundation

class LiveFFTAnalyzer {
    private var engine = AVAudioEngine()
    private var fftSetup: FFTSetup?

    func startAnalysis(callback: @escaping ([Int: Float]) -> Void) {
        let input = engine.inputNode
        let format = input.inputFormat(forBus: 0)
        let frameLength = 1024
        fftSetup = vDSP_create_fftsetup(vDSP_Length(log2(Float(frameLength))), FFTRadix(kFFTRadix2))

        input.installTap(onBus: 0, bufferSize: AVAudioFrameCount(frameLength), format: format) { buffer, time in
            guard let channelData = buffer.floatChannelData?[0] else { return }

            var window = [Float](repeating: 0, count: frameLength)
            vDSP_hann_window(&window, vDSP_Length(frameLength), Int32(vDSP_HANN_NORM))
            var inputSignal = [Float](repeating: 0, count: frameLength)
            vDSP_vmul(channelData, 1, window, 1, &inputSignal, 1, vDSP_Length(frameLength))

            var realp = [Float](repeating: 0, count: frameLength/2)
            var imagp = [Float](repeating: 0, count: frameLength/2)
            var output = DSPSplitComplex(realp: &realp, imagp: &imagp)
            inputSignal.withUnsafeBufferPointer {
                $0.baseAddress!.withMemoryRebound(to: DSPComplex.self, capacity: frameLength) {
                    vDSP_ctoz($0, 2, &output, 1, vDSP_Length(frameLength/2))
                }
            }

            vDSP_fft_zrip(self.fftSetup!, &output, 1, vDSP_Length(log2(Float(frameLength))), FFTDirection(FFT_FORWARD))

            var magnitudes = [Float](repeating: 0.0, count: frameLength/2)
            vDSP_zvmags(&output, 1, &magnitudes, 1, vDSP_Length(frameLength/2))

            var results = [Int: Float]()
            for i in 0..<frameLength/2 {
                let freq = Int(Float(i) * format.sampleRate / Float(frameLength))
                results[freq] = magnitudes[i]
            }
            callback(results)
        }

        try? engine.start()
    }

    func stopAnalysis() {
        engine.stop()
        engine.inputNode.removeTap(onBus: 0)
        if let setup = fftSetup {
            vDSP_destroy_fftsetup(setup)
        }
    }
}
