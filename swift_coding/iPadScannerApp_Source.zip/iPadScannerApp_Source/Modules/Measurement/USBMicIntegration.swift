
import Foundation
import AVFoundation

class USBMicIntegration {
    static func listInputDevices() -> [AVAudioSessionPortDescription] {
        let session = AVAudioSession.sharedInstance()
        return session.availableInputs ?? []
    }

    static func selectInput(named deviceName: String) {
        guard let input = listInputDevices().first(where: { $0.portName == deviceName }) else { return }
        try? AVAudioSession.sharedInstance().setPreferredInput(input)
    }
}
