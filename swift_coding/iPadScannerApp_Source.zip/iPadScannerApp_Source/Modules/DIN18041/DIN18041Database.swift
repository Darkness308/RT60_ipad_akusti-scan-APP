
import Foundation

class DIN18041Database {
    static func targets(for roomType: RoomType, volume: Double) -> [DIN18041Target] {
        switch roomType {
        case .classroom:
            if volume < 250 {
                return [
                    DIN18041Target(frequency: 125, targetRT60: 0.7, tolerance: 0.1),
                    DIN18041Target(frequency: 250, targetRT60: 0.6, tolerance: 0.1),
                    DIN18041Target(frequency: 500, targetRT60: 0.55, tolerance: 0.1),
                    DIN18041Target(frequency: 1000, targetRT60: 0.5, tolerance: 0.1),
                    DIN18041Target(frequency: 2000, targetRT60: 0.5, tolerance: 0.1),
                    DIN18041Target(frequency: 4000, targetRT60: 0.5, tolerance: 0.1),
                    DIN18041Target(frequency: 8000, targetRT60: 0.5, tolerance: 0.1)
                ]
            }
        default:
            return []
        }
    }
}
