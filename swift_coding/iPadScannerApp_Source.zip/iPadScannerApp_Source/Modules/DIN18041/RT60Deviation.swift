
import Foundation

enum EvaluationStatus: String, Codable {
    case withinTolerance = "Erfüllt"
    case tooHigh = "Überschritten"
    case tooLow = "Unterschritten"
}

struct RT60Deviation: Codable {
    let frequency: Int
    let simulated: Double
    let target: Double
    let deviation: Double
    let status: EvaluationStatus
}
