
import Foundation

class RT60Evaluator {
    static func evaluate(
        measurements: [RT60Measurement],
        roomType: RoomType,
        volume: Double
    ) -> [RT60Deviation] {
        let targets = DIN18041Database.targets(for: roomType, volume: volume)

        return measurements.compactMap { measurement in
            guard let target = targets.first(where: { $0.frequency == measurement.frequency }) else {
                return nil
            }
            let diff = measurement.simulated - target.targetRT60
            let status: EvaluationStatus
            if abs(diff) <= target.tolerance {
                status = .withinTolerance
            } else if diff > 0 {
                status = .tooHigh
            } else {
                status = .tooLow
            }
            return RT60Deviation(
                frequency: measurement.frequency,
                simulated: measurement.simulated,
                target: target.targetRT60,
                deviation: diff,
                status: status
            )
        }
    }
}
