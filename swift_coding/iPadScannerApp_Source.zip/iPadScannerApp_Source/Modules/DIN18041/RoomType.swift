
import Foundation

enum RoomType: String, CaseIterable, Codable {
    case classroom
    case conferenceRoom
    case gym
    case office

    var displayName: String {
        switch self {
        case .classroom: return "Klassenraum"
        case .conferenceRoom: return "Konferenzraum"
        case .gym: return "Sporthalle"
        case .office: return "Büro"
        }
    }
}
