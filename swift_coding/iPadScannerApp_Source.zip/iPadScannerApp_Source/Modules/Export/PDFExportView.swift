import SwiftUI
import PDFKit

struct PDFExportView: View {
    @ObservedObject var store: SurfaceStore

    var body: some View {
        VStack {
            Button("Exportiere RT60 als PDF") {
                exportAsPDF()
            }
            .font(.headline)
            .padding()

            Spacer()
        }
        .navigationTitle("PDF Export")
    }

    func exportAsPDF() {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("RT60_Akustikbericht.pdf")
        let pageWidth = 595.2
        let pageHeight = 841.8
        let bounds = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)

        let format = UIGraphicsPDFRendererFormat()
        let renderer = UIGraphicsPDFRenderer(bounds: bounds, format: format)

        do {
            try renderer.writePDF(to: url) { ctx in
                ctx.beginPage()

                let headline = "RT60-Auswertung"
                headline.draw(at: CGPoint(x: 40, y: 40), withAttributes: [
                    .font: UIFont.boldSystemFont(ofSize: 20)
                ])

                var y = 80.0
                for freq in [125, 250, 500, 1000, 2000, 4000, 8000] {
                    let rt60 = calculateRT60(frequency: freq)
                    let line = "\(freq) Hz: \(String(format: "%.2f", rt60)) s"
                    line.draw(at: CGPoint(x: 40, y: y), withAttributes: [
                        .font: UIFont.systemFont(ofSize: 14)
                    ])
                    y += 20
                }

                y += 20
                for surface in store.surfaces {
                    let line = "\(surface.name): \(String(format: "%.2f", surface.area)) m² - \(surface.materialType ?? "-")"
                    line.draw(at: CGPoint(x: 40, y: y), withAttributes: [
                        .font: UIFont.systemFont(ofSize: 12)
                    ])
                    y += 16
                }
            }
            print("PDF exportiert: \(url)")
        } catch {
            print("Fehler beim PDF-Export: \(error.localizedDescription)")
        }
    }

    func calculateRT60(frequency: Int) -> Float {
        var a_f: Float = 0.0
        for surface in store.surfaces {
            if let material = surface.materialType,
               let alpha = MaterialDatabase.absorption(for: material)?.values[frequency] {
                a_f += surface.area * alpha
            }
        }
        let volume = store.estimatedVolume
        return a_f > 0 ? 0.161 * volume / a_f : 0.0
    }
}
