import Foundation
import SwiftUI

class MaterialManager: ObservableObject {
    @Published var customMaterials: [AcousticMaterial] = []

    func add(_ material: AcousticMaterial) {
        customMaterials.append(material)
    }

    func remove(at offsets: IndexSet) {
        customMaterials.remove(atOffsets: offsets)
    }
}