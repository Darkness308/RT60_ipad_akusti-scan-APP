
import Foundation

class AbsorberCalculator {
    static func calculateRequiredAbsorberArea(
        for requirement: AbsorptionRequirement,
        with product: AbsorberProduct
    ) -> Double {
        guard product.absorptionCoefficient > 0 else { return 0.0 }
        return requirement.requiredAbsorption / product.absorptionCoefficient
    }

    static func calculateTotalCost(
        area: Double,
        product: AbsorberProduct
    ) -> Double {
        return area * product.pricePerSquareMeter
    }
}
