import Foundation
import Combine

class MockSurfaceStore: ObservableObject {
    @Published var surfaces: [Surface] = [
        Surface(area: 10.0, materialType: "Foam"),
        Surface(area: 20.0, materialType: "Wood")
    ]
    var estimatedVolume: Float { 120.0 }
}