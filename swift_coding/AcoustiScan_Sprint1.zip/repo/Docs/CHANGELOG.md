# Changelog

## 0.1.0 – 29.08.25 – Sprint 0 (Kick‑off)

* Neues Repository mit strukturierter Ordnerhierarchie angelegt.
* Bestandscode aus dem früheren Prototyp übertragen (Scanner, RT60,
  DIN18041, Material, Absorber, Export).
* `AppEntry` und `TabRootView` implementiert, um einen
  Tab‑basierten Navigationsrahmen zu schaffen.
* Erste Dokumente erstellt: README, Messleitfaden, Changelog,
  Backlog und Risikolog.
