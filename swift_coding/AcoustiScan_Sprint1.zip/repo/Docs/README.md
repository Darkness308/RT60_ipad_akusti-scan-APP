# AcoustiScan – iPad Raumakustik‑App (MVP)

Dieses Repository enthält den Quellcode für **AcoustiScan**, einen
experimentellen Prototyp zur orientierenden Messung der Raumakustik
auf dem iPad.  Die App nutzt LiDAR‑Scans, Audiosignalanalyse und
Normenvergleiche, um die Nachhallzeit (RT60) zu bestimmen und mit
den Zielwerten der DIN 18041 zu vergleichen.  Die Ergebnisse können
anschließend in einem PDF‑Bericht oder anderen Formaten exportiert
werden.

## Struktur

```
repo/
├─ App/                 # App‑Einstieg und SwiftUI‑Lifecycle
│  ├─ AppEntry.swift    # Einstiegspunkt – lädt TabRootView
│  ├─ Resources/        # Assets, Plist‑Dateien etc.
├─ Modules/             # Feature‑Module der Anwendung
│  ├─ Scanner/          # LiDAR‑Scan, Surface‑Erfassung (ARKit/RoomPlan)
│  ├─ Acoustics/
│  │   ├─ RT60/         # RT60‑Berechnung, Kurven, Filter
│  │   └─ Filters/      # Oktav- und Terzfilter (vDSP)
│  ├─ DIN18041/         # Normziele, Ampellogik
│  ├─ Material/         # Materialdatenbank, Editor
│  ├─ Export/           # PDF/CSV/XLSX‑Export, ShareSheet
│  ├─ AbsorberCalculation/ # Maßnahmenvorschläge
│  └─ UI/               # App‑weit verwendete Views (z. B. TabRootView)
├─ Tests/
│  ├─ Unit/             # Unit‑Tests für Kernmodule
│  └─ Integration/      # End‑to‑End‑Tests
└─ Docs/                # Dokumentation, Messleitfaden, Changelog, Backlog
```

## Aktueller Stand (Sprint 0)

Zum Kick‑off wurde ein Repo‑Skeleton erstellt, die bisherige
Prototyp‑Logik aus dem ursprünglichen Projekt übernommen und eine
einfache Tab‑Navigation implementiert.  In den kommenden Sprints
werden die Kernfunktionen Schritt für Schritt ergänzt (siehe
Backlog).

## Lizenz

Dieses Projekt befindet sich im frühen Entwicklungsstadium und ist
derzeit nicht für den produktiven Einsatz vorgesehen.  Eine Lizenz
wird nach Abschluss des MVPs definiert.
