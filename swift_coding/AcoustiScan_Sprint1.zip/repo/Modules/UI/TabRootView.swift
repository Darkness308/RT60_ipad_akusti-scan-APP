//  TabRootView.swift
//  AcoustiScan
//
//  Created during Sprint 0 kick‑off on 29.08.25.
//

import SwiftUI

/// The root view of the application.  It defines the high‑level tab
/// navigation used throughout the app.  Each tab will later host a
/// dedicated sub‑module (Room scanning, material selection, RT60
/// processing, DIN‑18041 analysis and report export).  For the kick‑off
/// sprint we use simple placeholder views that will be replaced in later
/// sprints.
public struct TabRootView: View {
    public init() {}
    public var body: some View {
        TabView {
            NavigationView {
                Text("Scan‑Modul (Platzhalter)")
                    .navigationTitle("Scan")
            }
            .tabItem {
                Label("Scan", systemImage: "viewfinder")
            }

            NavigationView {
                Text("Material‑Modul (Platzhalter)")
                    .navigationTitle("Material")
            }
            .tabItem {
                Label("Material", systemImage: "square.grid.2x2")
            }

            NavigationView {
                Text("RT60‑Modul (Platzhalter)")
                    .navigationTitle("RT60")
            }
            .tabItem {
                Label("RT60", systemImage: "waveform")
            }

            NavigationView {
                Text("DIN‑Modul (Platzhalter)")
                    .navigationTitle("DIN 18041")
            }
            .tabItem {
                Label("DIN", systemImage: "chart.bar.fill")
            }

            NavigationView {
                Text("Report‑Modul (Platzhalter)")
                    .navigationTitle("Report")
            }
            .tabItem {
                Label("Report", systemImage: "doc.plaintext")
            }
        }
    }
}
