
import Foundation

/// Enumeration of supported Raumtypen nach DIN 18041.
///
/// Die Werte orientieren sich an gängigen Nutzungskategorien der
/// Norm. Für jede Kategorie gibt es in der Datenbank eine passende
/// Formel zur Berechnung der Soll-Nachhallzeit (Tsoll) in Abhängigkeit
/// vom Raumvolumen.【588092373354603†L1055-L1080】
enum RoomType: String, CaseIterable, Codable {
    /// Unterrichts- bzw. Klassenraum. Entspricht "Lehr- und Unterrichtsräume" in der Norm.
    case classroom
    /// Konferenz- bzw. Besprechungsraum für Sprache.
    case conferenceRoom
    /// Sporthalle oder Mehrzweckhalle. Mangels spezifischer Formel wird hier die Sprachformel verwendet.
    case gym
    /// Büro oder kleinerer Raum für Sprache.
    case office
    /// Musik- oder Probenraum. Dieser Typ erhält eine separate Formel (Musikräume).
    case musicRoom

    /// Benutzerfreundlicher Name für das UI.
    var displayName: String {
        switch self {
        case .classroom: return "Klassenraum"
        case .conferenceRoom: return "Konferenzraum"
        case .gym: return "Sporthalle"
        case .office: return "Büro"
        case .musicRoom: return "Musikraum"
        }
    }
}
