
import Foundation

struct DIN18041Target: Codable {
    let frequency: Int
    let targetRT60: Double
    let tolerance: Double
}
