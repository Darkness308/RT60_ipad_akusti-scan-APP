
import Foundation

struct AbsorberProduct: Codable {
    let name: String
    let frequencyBand: Int  // Hauptwirksamkeit (z. B. 500Hz)
    let absorptionCoefficient: Double
    let pricePerSquareMeter: Double
}
