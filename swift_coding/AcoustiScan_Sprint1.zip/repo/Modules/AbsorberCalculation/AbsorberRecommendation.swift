
import Foundation

struct AbsorberRecommendation {
    let frequency: Int
    let product: AbsorberProduct
    let areaNeeded: Double
    let totalCost: Double
}
