import simd
import Foundation

struct LabeledSurface: Identifiable, Codable {
    let id: UUID = UUID()
    var name: String
    var position: SIMD3<Float>
    var absorptionCoefficient: Double
    var colorHex: String
    var area: Float

    var absorptionArea: Double {
        return Double(area) * absorptionCoefficient
    }
}

class SurfaceStore: ObservableObject {
    @Published var surfaces: [LabeledSurface] = []

    func add(name: String, position: SIMD3<Float>, area: Float, absorptionCoefficient: Double, colorHex: String = "#999999") {
        let surface = LabeledSurface(
            name: name,
            position: position,
            absorptionCoefficient: absorptionCoefficient,
            colorHex: colorHex,
            area: area
        )
        surfaces.append(surface)
    }

    func updateAbsorption(for id: UUID, to newCoefficient: Double) {
        if let index = surfaces.firstIndex(where: { $0.id == id }) {
            surfaces[index].absorptionCoefficient = newCoefficient
        }
    }

    var estimatedVolume: Float {
        let height: Float = 2.5
        let baseArea = surfaces.map { $0.area }.max() ?? 25.0
        return baseArea * height
    }
}
