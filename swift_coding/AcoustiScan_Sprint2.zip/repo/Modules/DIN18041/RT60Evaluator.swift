
import Foundation

class RT60Evaluator {
    /// Klassifiziert eine gemessene Nachhallzeit relativ zum Zielwert.
    ///
    /// Dieser Hilfsrückgabewert ist speziell für Unit‑Tests gedacht. Er abstrahiert
    /// von der detaillierteren `EvaluationStatus` und verwendet die Bezeichnungen
    /// `.withinRange`, `.tooHigh` und `.tooLow`, um festzustellen, ob der
    /// gemessene Wert innerhalb einer Toleranz liegt.
    enum RangeStatus: Equatable {
        case withinRange
        case tooHigh
        case tooLow
    }

    /// Klassifiziert die gemessene Nachhallzeit im Verhältnis zum Sollwert.
    ///
    /// Die Toleranz wird aus DIN 18041 abgeleitet und beträgt den größeren
    /// Wert aus 0,2 Sekunden oder 10 % des Sollwerts【588092373354603†L1055-L1060】.
    /// - Parameters:
    ///   - measured: Die gemessene Nachhallzeit (s).
    ///   - target: Der Sollwert aus der Norm (s).
    /// - Returns: Eine `RangeStatus`‑Kategorie.
    static func classifyRT60(measured: Double, target: Double) -> RangeStatus {
        // Normative Toleranz: max(0,2 s, 10 % × target)
        let tolerance = max(0.2, 0.1 * target)
        let diff = measured - target
        if abs(diff) <= tolerance {
            return .withinRange
        } else if diff > 0 {
            return .tooHigh
        } else {
            return .tooLow
        }
    }

    /// Bewertet die Messungen einer ganzen Frequenzreihe für einen Raumtyp und ein Volumen.
    ///
    /// Für jede Messung wird der Sollwert und die Toleranz aus der Norm
    /// abgeleitet und mit dem gemessenen Wert verglichen. Das Ergebnis ist eine
    /// Liste von `RT60Deviation` mit detailliertem Status.
    /// - Parameters:
    ///   - measurements: Gemessene oder simulierte RT60‑Werte je Frequenz.
    ///   - roomType: Typ des Raums gemäß `RoomType`.
    ///   - volume: Raumvolumen (m³).
    /// - Returns: Eine Liste der Abweichungen und Klassifikationen.
    static func evaluate(
        measurements: [RT60Measurement],
        roomType: RoomType,
        volume: Double
    ) -> [RT60Deviation] {
        let targets = DIN18041Database.targets(for: roomType, volume: volume)

        return measurements.compactMap { measurement in
            guard let target = targets.first(where: { $0.frequency == measurement.frequency }) else {
                return nil
            }
            let diff = measurement.simulated - target.targetRT60
            let status: EvaluationStatus
            if abs(diff) <= target.tolerance {
                status = .withinTolerance
            } else if diff > 0 {
                status = .tooHigh
            } else {
                status = .tooLow
            }
            return RT60Deviation(
                frequency: measurement.frequency,
                simulated: measurement.simulated,
                target: target.targetRT60,
                deviation: diff,
                status: status
            )
        }
    }
}
