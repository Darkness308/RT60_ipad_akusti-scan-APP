
import Foundation

struct RT60Measurement: Codable {
    let frequency: Int
    let simulated: Double
    let measured: Double?
}
