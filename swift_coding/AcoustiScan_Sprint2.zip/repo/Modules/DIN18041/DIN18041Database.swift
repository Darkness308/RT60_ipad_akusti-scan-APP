
import Foundation

class DIN18041Database {
    /// Liste der Standard-Oktavfrequenzen für die Zielwerte.
    private static let frequencies: [Int] = [125, 250, 500, 1000, 2000, 4000, 8000]

    /// Berechnet die Ziel-Nachhallzeiten (Tsoll) und Toleranzen für einen gegebenen Raumtyp und das Volumen.
    ///
    /// Die Formeln basieren auf DIN 18041 und liefern eine frequenzunabhängige Soll-Nachhallzeit für das unmöblierte Volumen V【588092373354603†L1055-L1080】.
    /// Für Musikräume gilt: Tsoll = 0,45 × log10(V/m³) + 0,07.
    /// Für Sprachräume (Besprechung, Büro, Sporthalle): Tsoll = 0,37 × log10(V/m³) − 0,14.
    /// Für Lehr-/Unterrichtsräume: Tsoll = 0,32 × log10(V/m³) − 0,17.
    /// Die Rückgabe liefert pro Oktavfrequenz einen `DIN18041Target` mit identischem Sollwert und einer Toleranz von max(0,2 s, 10 % × Tsoll).
    ///
    /// - Parameters:
    ///   - roomType: Der Raumtyp laut Enumeration.
    ///   - volume: Das Raumvolumen in Kubikmetern.
    /// - Returns: Eine Liste von Sollwerten und Toleranzen je Oktavband.
    static func targets(for roomType: RoomType, volume: Double) -> [DIN18041Target] {
        // Sicherstellen, dass das Volumen positiv ist, um log10 definieren zu können.
        let safeVolume = max(volume, 1.0)
        let logV = log10(safeVolume)

        // Bestimmen des Basis-Sollwerts je Raumtyp nach Norm.
        let baseRT: Double
        switch roomType {
        case .musicRoom:
            // Musikräume【588092373354603†L1055-L1080】
            baseRT = 0.45 * logV + 0.07
        case .classroom:
            // Lehr-/Unterrichtsräume【588092373354603†L1055-L1080】
            baseRT = 0.32 * logV - 0.17
        case .conferenceRoom, .office, .gym:
            // Sprachräume【588092373354603†L1055-L1080】
            baseRT = 0.37 * logV - 0.14
        }

        // Die Norm fordert, dass die Nachhallzeit eines unbelegten Raums höchstens 0,2 s über Tsoll liegen darf【588092373354603†L1055-L1060】.
        // Wir verwenden diese Anforderung als Toleranzbasis und ergänzen eine prozentuale Toleranz von 10 % des Sollwertes.
        let absoluteTolerance = 0.2
        let relativeTolerance = 0.1 * baseRT
        let tolerance = max(absoluteTolerance, relativeTolerance)

        // Erzeuge ein Target für jede Frequenz mit dem selben Sollwert und berechneter Toleranz.
        return Self.frequencies.map { freq in
            DIN18041Target(frequency: freq, targetRT60: baseRT, tolerance: tolerance)
        }
    }
}
