
import Foundation

struct AbsorptionRequirement {
    let frequency: Int
    let requiredAbsorption: Double
}
