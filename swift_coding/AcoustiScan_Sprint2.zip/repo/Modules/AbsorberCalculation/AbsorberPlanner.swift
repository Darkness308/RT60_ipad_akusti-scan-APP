
import Foundation

class AbsorberPlanner {
    static func recommendAbsorbers(
        requirements: [AbsorptionRequirement],
        availableProducts: [AbsorberProduct]
    ) -> [AbsorberRecommendation] {
        var recommendations: [AbsorberRecommendation] = []

        for req in requirements {
            if let bestMatch = availableProducts
                .filter({ $0.frequencyBand == req.frequency })
                .sorted(by: { $0.absorptionCoefficient > $1.absorptionCoefficient })
                .first {

                let area = AbsorberCalculator.calculateRequiredAbsorberArea(for: req, with: bestMatch)
                let cost = AbsorberCalculator.calculateTotalCost(area: area, product: bestMatch)

                let rec = AbsorberRecommendation(
                    frequency: req.frequency,
                    product: bestMatch,
                    areaNeeded: area,
                    totalCost: cost
                )
                recommendations.append(rec)
            }
        }

        return recommendations
    }
}
