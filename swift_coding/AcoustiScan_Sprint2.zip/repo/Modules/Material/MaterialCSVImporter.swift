//  MaterialCSVImporter.swift
//  AcoustiScan
//
//  Created in Sprint 2 (RoomPlan & Material) on 29.08.25.
//
//  Dieses Utility dient dem Import und Export von akustischen
//  Materialdaten im CSV‑Format.  Die erwartete Struktur einer CSV
//  lautet:
//  `name;125;250;500;1000;2000;4000;8000` (einschließlich Kopfzeile).
//  Zeilen mit unpassender Länge werden übersprungen.  Dezimalzahlen
//  dürfen einen Punkt oder ein Komma als Trennzeichen verwenden.

import Foundation

struct MaterialCSVImporter {
    /// Importiert eine Liste von `AcousticMaterial` aus einer CSV‑Datei.
    /// - Parameter url: Die Datei‑URL zur CSV.
    /// - Returns: Ein Array von Materialien.
    static func importFromFile(url: URL) throws -> [AcousticMaterial] {
        let data = try Data(contentsOf: url)
        guard let content = String(data: data, encoding: .utf8) else { return [] }
        return parseCSV(content)
    }

    /// Parst eine CSV‑Zeichenkette in eine Liste von Materialien.
    /// - Parameter csv: Inhalt der CSV.
    /// - Returns: Ein Array von Materialien.
    static func parseCSV(_ csv: String) -> [AcousticMaterial] {
        var materials: [AcousticMaterial] = []
        // Zeilen aufteilen und leere Zeilen entfernen
        let lines = csv.components(separatedBy: CharacterSet.newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        guard let headerLine = lines.first else { return [] }
        let headers = headerLine.split(separator: ";").map { String($0) }
        // Frequenzen aus der Kopfzeile (alle Spalten außer dem Namen)
        let freqHeaders = headers.dropFirst().compactMap { Int($0.trimmingCharacters(in: .whitespaces)) }
        for line in lines.dropFirst() {
            let fields = line.split(separator: ";").map { String($0) }
            // Ein Material benötigt einen Namen und Werte für jede Frequenz
            guard fields.count == freqHeaders.count + 1 else { continue }
            let name = fields[0].trimmingCharacters(in: .whitespaces)
            var values: [Int: Float] = [:]
            for (index, freq) in freqHeaders.enumerated() {
                let raw = fields[index + 1].trimmingCharacters(in: .whitespaces)
                // Komma als Dezimaltrennzeichen zulassen
                let normalized = raw.replacingOccurrences(of: ",", with: ".")
                let alpha = Float(normalized) ?? 0.0
                values[freq] = alpha
            }
            let material = AcousticMaterial(name: name, absorption: AbsorptionData(values: values))
            materials.append(material)
        }
        return materials
    }

    /// Exportiert eine Liste von Materialien als CSV‑String.
    /// - Parameter materials: Materialien, die exportiert werden sollen.
    /// - Returns: Eine CSV‑Zeichenkette mit Kopfzeile und Zeilen.
    static func exportCSV(materials: [AcousticMaterial]) -> String {
        // Sammle alle Frequenzen aus den Materialien, um eine einheitliche Kopfzeile zu erzeugen
        let allFreqs = materials.flatMap { $0.absorption.values.keys }
        let sortedFreqs = Array(Set(allFreqs)).sorted()
        let header = ["name"] + sortedFreqs.map { String($0) }
        var rows: [String] = []
        rows.append(header.joined(separator: ";"))
        for material in materials {
            var line: [String] = [material.name]
            for freq in sortedFreqs {
                if let value = material.absorption.values[freq] {
                    // Werte mit Komma als Dezimaltrenner formatieren
                    line.append(String(format: "%.3f", value).replacingOccurrences(of: ".", with: ","))
                } else {
                    line.append("")
                }
            }
            rows.append(line.joined(separator: ";"))
        }
        return rows.joined(separator: "\n")
    }
}