# Risiko‑Log

Dieses Dokument sammelt technische und betriebliche Risiken, die während
der Entwicklung des MVPs identifiziert werden.  Jedes Risiko erhält
eine Einschätzung (hoch/mittel/niedrig) und ggf. eine Gegenmaßnahme.

| Risiko | Bewertung | Gegenmaßnahme |
|-------|-----------|---------------|
| **Mikrofon‑Kalibrierung** – unkalibrierte Mikrofone führen zu falschen RT60‑Werten. | hoch | Einbindung einer Kalibrier‑Routine und Unterstützung für externe Messmikrofone; Verwendung standardisierter Kalibrier‑Dateien. |
| **Störgeräusche** – Hintergrundgeräusche verfälschen die Energieabklingkurve und somit T20/T30【473764854244230†L229-L236】. | hoch | Vor der Messung Lärmpegel messen, Mindest­pegel­unterschied prüfen; Anwender durch Warnhinweise führen. |
| **Messdauer** – zu kurze Anregung oder zu kurze Aufnahme beeinflusst das Ergebnis. | mittel | Automatische Prüfung der Aufnahme­länge relativ zur erwarteten Nachhallzeit; Hinweis an den Anwender. |
| **RoomPlan‑Stabilität** – Erkennungsfehler bei komplexen Räumen (z. B. stark möbliert). | mittel | Option für manuelle Korrekturen; Verwendung der neuesten ARKit/RoomPlan APIs (Stand 2025). |
| **Performance & Speicher** – Berechnung der Impulsantwort und PDF‑Generierung darf das Gerät nicht überlasten. | niedrig | Nutzung von Accelerate/vDSP und asynchroner Verarbeitung; Speichersparende PDF‑Layouts. |
| **Norm‑Updates** – Änderung der DIN 18041 oder neuer Standards nach 2024. | niedrig | Hinterlegung der Ziel­formeln in einer Datenbank, die bei Bedarf aktualisiert werden kann. |
| **Rechtliche Haftung** – falsch interpretierte Ergebnisse könnten zu Fehlentscheidungen führen. | mittel | Deutlicher Hinweis im Messleitfaden und in der App, dass es sich um eine orientierende Messung handelt. |

> Dieser Risikolog wird fortlaufend ergänzt und angepasst.
