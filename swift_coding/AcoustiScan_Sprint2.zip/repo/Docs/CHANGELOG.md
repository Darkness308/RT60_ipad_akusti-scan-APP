# Changelog

## 0.1.0 – 29.08.25 – Sprint 0 (Kick‑off)

* Neues Repository mit strukturierter Ordnerhierarchie angelegt.
* Bestandscode aus dem früheren Prototyp übertragen (Scanner, RT60,
  DIN18041, Material, Absorber, Export).
* `AppEntry` und `TabRootView` implementiert, um einen
  Tab‑basierten Navigationsrahmen zu schaffen.
* Erste Dokumente erstellt: README, Messleitfaden, Changelog,
  Backlog und Risikolog.

## 0.2.0 – 29.08.25 – Sprint 1 (RT60 & DIN)

* **RT60‑Pipeline:** Ein neues Modul `ImpulseResponseAnalyzer` implementiert die Schroeder‑Integration, berechnet Energiezerfallskurven und ermittelt T20/T30‑Werte aus Impulsantworten. Die Funktion `rt60(ir:sampleRate:)` liefert automatisiert die beste Messdauer (T30, falls möglich, sonst T20) gemäß ISO 3382【473764854244230†L186-L204】【904610549343461†L100-L124】.
* **DIN 18041 Datenbank:** `DIN18041Database.targets()` berechnet nun Ziel‑RT60‑Werte dynamisch in Abhängigkeit von Raumtyp und Volumen. Die Formeln basieren auf der Norm (Musik‑, Sprach‑ und Unterrichtsräume) und liefern pro Oktavband identische Sollwerte sowie eine Toleranz von max(0,2 s, 10 % × Tsoll)【588092373354603†L1055-L1080】.
* **RoomType:** Neue Kategorie `musicRoom` ergänzt die bisherigen Raumtypen und erlaubt korrekte Berechnungen für Proben- oder Musikräume.
* **RT60Evaluator:** Erweiterte Methode `classifyRT60(measured:target:)` klassifiziert gemessene Werte relativ zum Sollwert und gibt eine vereinfachte `RangeStatus` (withinRange/tooHigh/tooLow) zurück. Unit‑Tests verwenden diese Funktion.
* **Tests & QA:** Platzhalter‑Tests für die alten Methoden wurden angepasst; künftige Tests können `ImpulseResponseAnalyzer` und die DIN‑Formeln verifizieren.

## 0.3.0 – 29.08.25 – Sprint 2 (RoomPlan & Material)

* **RoomPlan‑Integration (Skeleton):** Neues Modul `RoomScanView` mit zugehörigem `RoomScanCoordinator` nutzt das RoomPlan‑Framework (sofern verfügbar), um LiDAR‑basierte Raumscans zu starten und zu beenden. Bis echte Scans getestet werden können, fügt der Coordinator beispielhaft eine Bodenfläche hinzu und dokumentiert Annahmen in den Kommentaren.
* **Material‑Import/Export:** Hinzugefügtes Utility `MaterialCSVImporter` ermöglicht das Einlesen von Materialien aus CSV‑Dateien (Struktur: `name;125;250;500;1000;2000;4000;8000`) und das Exportieren vorhandener Materialien in dasselbe Format. Dezimaltrennzeichen (Punkt oder Komma) werden berücksichtigt.
* **MaterialManager:** Erweiterte API für CSV‑Import und ‑Export. Materialien lassen sich jetzt aus einer CSV‑Zeichenkette oder Datei importieren; bestehende `customMaterials` werden dabei ersetzt. Ein Export liefert einen CSV‑String mit Kopfzeile und allen definierten Frequenzen.


