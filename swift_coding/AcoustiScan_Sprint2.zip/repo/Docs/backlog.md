# Product Backlog

Die folgenden User Stories und Tasks dienen als Ausgangspunkt für die
kommenden Sprints.  Die EKS‑Priorisierung (1 = höchste
Priorität) orientiert sich an den definierten Kernzielen.

| ID | Beschreibung | Sprint | EKS‑Priorität |
|----|--------------|--------|---------------|
| US‑1 | Als User möchte ich einen Raum via RoomPlan scannen, um die geometrischen Parameter (Volumen, Flächen) automatisch zu erfassen. | S2 (in Arbeit) | 3 |
| US‑2 | Als User möchte ich jeder erkannten Fläche ein Material zuordnen, um die Absorptionskoeffizienten zu berücksichtigen. | S2 (in Arbeit) | 3 |
| US‑3 | Als User möchte ich die Impulsantwort des Raums messen (T20/T30), damit die RT60‑Werte in Oktav-/Terzbandbreite ermittelt werden können. | S1 (done) | 1 |
| US‑4 | Als User möchte ich die gemessenen RT60‑Werte mit den DIN 18041 Zielwerten vergleichen, um eine Ampel‑Bewertung zu erhalten. | S1 (done) | 1 |
| US‑5 | Als User möchte ich einen PDF‑Bericht mit Kurven, Ampel und Maßnahmen exportieren können. | S3 | 2 |
| US‑6 | Als User möchte ich Material‑Daten per CSV/XLSX importieren und exportieren können. | S2 | 4 |
| US‑7 | Als User möchte ich einen JSON‑Audit‑Trail der Messung erhalten, um die Messkette nachvollziehbar zu machen. | S4 | 4 |
| US‑8 | Als User möchte ich Empfehlungen zu zusätzlichen Absorbern erhalten, um Ziel‑RT60 zu erreichen. | S4 | 5 |
| US‑9 | Als User möchte ich einen Mess‑Wizard mit Fehlerführung und Tooltips, um sicher durch die Messung geleitet zu werden. | S3 | 5 |
| US‑10 | Als Entwickler möchte ich Unit‑ und Integrationstests (>80 % Kernmodule) implementieren, um die Qualität abzusichern. | S4 | 2 |

> Hinweis: Dieses Backlog ist lebendig und wird während der Entwicklung angepasst.
