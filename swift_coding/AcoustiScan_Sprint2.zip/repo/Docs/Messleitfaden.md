# Messleitfaden für die orientierende Nachhallzeitmessung

Dieser Leitfaden beschreibt, wie die App **AcoustiScan** zur
orientierenden Bestimmung der Nachhallzeit RT60 verwendet wird.
Die Messung dient lediglich der Vorab‑Analyse (z. B. für
Erstbewertungen, Angebotskalkulationen oder Planungen) und ersetzt
keine abnahmerelevanten Prüfungen gemäß DIN EN ISO 3382.

## Vorbereitungen

1. **Hardware** – Nutzen Sie ein iPad Pro mit LiDAR‑Sensor
   (mindestens Baujahr 2022) und ein kalibriertes externes
   Messmikrofon, das über USB‑C oder Lightning angeschlossen wird.
2. **Kalibrierung** – Führen Sie vor der Messung eine
   Mikrofon‑Kalibrierung mit einem Referenzschallpegel (z. B. 94 dB
   bei 1 kHz) durch.  Hinterlegen Sie die Kalibrierkurve als CSV oder
   FRD‑Datei in der App.
3. **Störgeräusche** – Achten Sie auf niedrige Hintergrundgeräusche; der
   Differenzpegel zwischen Messsignal und Umgebung sollte mindestens
   35 dB betragen (für T20) bzw. 45 dB (für T30)【473764854244230†L229-L236】.

## Messablauf

1. **Raum scannen** – Starten Sie den Scan in der *Scan*‑Ansicht.
   Führen Sie das iPad langsam entlang der Raumbegrenzungen; die App
   nutzt das LiDAR‑Modul (RoomPlan) um Wände, Boden und Decke
   parametisch zu erfassen.
2. **Oberflächen taggen** – Weisen Sie den erkannten Flächen
   Materialtypen zu (z. B. Betonwand, Teppichboden).  Die
   Absorptionsdaten werden aus der Materialdatenbank geladen.
3. **Impulsantwort aufnehmen** – Erzeugen Sie ein Messsignal (z. B.
   MLS‑Sequenz oder Burst) und zeichnen Sie die Raumantwort über das
   Mikrofon auf.  Die App berechnet daraus die Energieabklingkurve
   (Schroeder‑Integration) und leitet daraus T20/T30‑Werte ab【904610549343461†L100-L124】.
4. **RT60‑Berechnung** – Für jede Oktav‑ bzw. Terzbandfrequenz wird
   die lineare Regression innerhalb der relevanten Pegelbereiche
   berechnet.  T20 ergibt sich aus dem Zeitintervall zwischen 5 dB und
   25 dB Abfall und wird mit 3 multipliziert; T30 entsprechend aus
   5 dB bis 35 dB Abfall mal 2【904610549343461†L115-L124】.
5. **DIN‑Analyse** – Die gemessenen RT60‑Werte werden mit den
   Zielwerten der DIN 18041 verglichen (abhängig von Raumvolumen
   und Nutzung)【588092373354603†L1055-L1080】.  Eine Ampel‑Logik zeigt an,
   ob die Vorgaben eingehalten werden.

## Scope und Haftungsausschluss

Die vorliegenden Messungen sind **orientierend**.  Sie dienen der
Erstbeurteilung und können Planungsentscheidungen unterstützen.  Für
rechtsverbindliche Nachweise oder Abnahmen müssen gemäß den
einschlägigen Normen (DIN EN ISO 3382, VDI 2569 etc.) zertifizierte
Messgeräte und Verfahren eingesetzt werden.  Die Entwickler dieser
App übernehmen keine Haftung für fehlerhafte Messungen oder deren
Konsequenzen.
