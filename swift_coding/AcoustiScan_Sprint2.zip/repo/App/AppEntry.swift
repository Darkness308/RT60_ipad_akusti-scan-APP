//  AppEntry.swift
//  AcoustiScan
//
//  Created by Sprint0 on 29.08.25.
//

import SwiftUI

/// The application entry point.  This struct sets up a single scene hosting
/// our `TabRootView` which contains the high‑level navigation for the MVP.
@main
struct AppEntry: App {
    var body: some Scene {
        WindowGroup {
            TabRootView()
        }
    }
}
