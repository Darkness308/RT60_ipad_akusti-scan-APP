import XCTest
@testable import iPadScannerApp

final class AbsorberCalculatorTests: XCTestCase {
    func testRequiredAbsorptionCalculation() {
        let roomVolume = 100.0
        let currentRT60 = 1.4
        let targetRT60 = 1.0
        let expected = (roomVolume * (currentRT60 - targetRT60)) / targetRT60
        let result = AbsorberCalculator.requiredAbsorption(volume: roomVolume, currentRT60: currentRT60, targetRT60: targetRT60)
        XCTAssertEqual(result, expected, accuracy: 0.001)
    }

    func testNoAbsorptionNeededIfTargetMet() {
        let result = AbsorberCalculator.requiredAbsorption(volume: 80.0, currentRT60: 1.0, targetRT60: 1.0)
        XCTAssertEqual(result, 0.0)
    }
}