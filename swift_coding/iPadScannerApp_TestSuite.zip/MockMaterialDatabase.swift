struct MockMaterialDatabase {
    static func absorption(for material: String) -> [Int: Float]? {
        return ["Wood", "Concrete", "Foam"].contains(material) ? [
            125: 0.10, 250: 0.20, 500: 0.30,
            1000: 0.40, 2000: 0.50, 4000: 0.60, 8000: 0.70
        ] : nil
    }
}