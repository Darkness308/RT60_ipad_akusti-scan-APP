import XCTest
@testable import iPadScannerApp

final class RT60ChartViewTests: XCTestCase {
    func testCalculateRT60At500Hz() {
        let mockStore = MockSurfaceStore()
        let view = RT60ChartView(store: mockStore)
        let rt60 = view.calculateRT60(frequency: 500)
        XCTAssert(rt60 > 0.0 && rt60 < 10.0)
    }
}