#!/bin/bash
echo "🧪 Running Swift Unit Tests..."
xcodebuild \
  -scheme iPadScannerApp \
  -sdk iphonesimulator \
  -destination 'platform=iOS Simulator,name=iPhone 14' \
  clean test | tee test-report.log | xcpretty